export interface ProjectItem {
  id: string;
  title: string;
  category: 'software' | 'mobile' | 'iot' | 'design' | 'research' | 'plc' | 'electronics';
  categoryLabel: string;
  subtitle: string;
  summary: string;
  fullDescription: string;
  tags: string[];
  image: string;
  featured?: boolean;
  date: string;
  githubUrl?: string;
  liveUrl?: string;
  publicationUrl?: string;
  highlights: string[];
}

export interface PublicationItem {
  id: string;
  title: string;
  authors: string;
  venue: string;
  year: string;
  documentId: string;
  url: string;
  doi?: string;
  abstract: string;
  tags: string[];
  category: string;
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  period: string;
  location: string;
  type: 'Full-time' | 'Remote' | 'Internship';
  description: string;
  achievements: string[];
  skills: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  period: string;
  location: string;
  details: string;
  courses: string[];
}

export interface SkillItem {
  name: string;
  percentage: number;
  category: 'web' | 'software' | 'mobile' | 'design' | 'cloud' | 'plc' | 'electronics';
  categoryLabel: string;
  level: string;
}

export interface ExhibitionItem {
  id: string;
  title: string;
  year: string;
  venue: string;
  role: string;
  description: string;
  badge: string;
}

export const CV_DATA = {
  profile: {
    name: 'Nuwan Prasanna',
    title: 'Software Engineer & Creative Technologist',
    degree: 'B.Eng. Tech (Hons), University of Sri Jayewardenepura',
    email: 'nuwanekanayaka6@gmail.com',
    phones: ['+94 754899858', '+94 712718506'],
    location: 'Rathpaha Niwasa, Perawella, Sri Lanka',
    birthday: 'June 30, 1996',
    avatar: '/src/assets/images/nuwan_tech_avatar_1790260919085.jpg',
    availability: 'Open for Full-Stack, Mobile & Engineering Roles',
    summary:
      'Bachelor of Engineering Technology (Honours) graduate from the Faculty of Technology, University of Sri Jayewardenepura, and IEEE published researcher (IEEE Xplore Doc 10688954). Blends 5+ years of creative expertise in 3D modeling and animation with robust full-stack software development (.NET, C#, Python, React, Vue, Flutter, Laravel), industrial PLC automation, and electronic hardware engineering.',
    socials: {
      github: 'https://github.com/nuwanprasanna',
      facebook: 'https://www.facebook.com/nuwan.prasanna.313924/',
      ezbugfix: 'https://ezbugfix.com',
      goldchords: 'https://goldchords.blogspot.com',
      ieee: 'https://ieeexplore.ieee.org/document/10688954',
      youtube1: 'Idea Infinity',
      youtube2: 'Woow Look'
    },
    metrics: [
      { label: 'Years Experience', value: '5+', sub: 'Software & Engineering' },
      { label: 'IEEE Publication', value: '10688954', sub: 'Peer-Reviewed Research' },
      { label: 'Projects Shipped', value: '120+', sub: 'Global Client Deliveries' },
      { label: 'Client Satisfaction', value: '99.4%', sub: 'Fiverr & Enterprise' }
    ]
  },

  experiences: [
    {
      id: 'exp-1',
      role: 'Fullstack Web Developer',
      company: 'Fiverr (Global Clients)',
      period: 'Jan 2020 – Present',
      location: 'Remote',
      type: 'Remote',
      description:
        'Architecting and deploying end-to-end web applications, microservices, and database systems for worldwide clients across e-commerce, media, and enterprise automation.',
      achievements: [
        'Built full-stack web solutions utilizing .NET Core, Laravel, React, and Vue.js with high test coverage and responsive UI.',
        'Designed modular RESTful APIs and optimized MySQL/PostgreSQL queries for low-latency request handling.',
        'Maintained consistent 5-star seller ratings across complex software implementation gigs.'
      ],
      skills: ['C#', '.NET', 'React', 'Vue.js', 'Laravel', 'REST APIs', 'MySQL']
    },
    {
      id: 'exp-2',
      role: 'Creative & 3D Designer',
      company: 'Fiverr (Global Clients)',
      period: 'Jan 2020 – Present',
      location: 'Remote',
      type: 'Remote',
      description:
        'Providing professional 3D hard-surface modeling, motion graphics, branding kits, and broadcast assets for digital brands and streaming creators.',
      achievements: [
        'Produced high-poly and low-poly 3D models and renders using Blender 3D, 3ds Max, and ZBrush.',
        'Designed animated Twitch stream packages, overlays, stinger transitions, and emote packs.',
        'Engineered custom branding vectors and UI assets using Adobe Illustrator and Photoshop.'
      ],
      skills: ['Blender 3D', 'Photoshop', 'Illustrator', 'After Effects', '3D Modeling']
    },
    {
      id: 'exp-3',
      role: 'Trainee Electronic Engineer',
      company: 'Vega Innovations (Pvt) Ltd',
      period: 'Aug 2019 – Feb 2020',
      location: 'Colombo, Sri Lanka',
      type: 'Internship',
      description:
        'Internship at South Asia’s pioneering electric supercar and EV technology manufacturer (Vega EVX). Supported hardware testing, electronics debugging, and IoT telemetry sensor modules.',
      achievements: [
        'Assisted in PCB diagnostic validation, micro-controller firmware testing, and sensor telemetry analysis.',
        'Collaborated directly with lead engineers on electronic control units (ECU) and data acquisition pipelines.',
        'Contributed to the environmental sensor array prototype ("Benefactor" Air Quality Monitor).'
      ],
      skills: ['Electronics & PCB', 'Microcontrollers', 'C/C++', 'Telemetry', 'IoT Sensors']
    },
    {
      id: 'exp-4',
      role: 'Graphic Designer',
      company: 'Manel Studio',
      period: 'Aug 2019 – Feb 2020',
      location: 'Sri Lanka',
      type: 'Full-time',
      description:
        'Led creative photo manipulation, typography branding, promotional print materials, and digital advertising layouts for commercial studio campaigns.',
      achievements: [
        'Delivered high-turnaround advertising and branding projects with Adobe Creative Suite.',
        'Supervised digital prepress color calibration and media production standards.'
      ],
      skills: ['Photoshop', 'Illustrator', 'CorelDraw', 'Color Grading', 'Typography']
    }
  ] as ExperienceItem[],

  education: [
    {
      id: 'edu-1',
      degree: 'Bachelor of Engineering Technology (Honours)',
      institution: 'University of Sri Jayewardenepura',
      period: 'Dec 2016 – Dec 2020',
      location: 'Faculty of Technology, Sri Lanka',
      details:
        'Four-year comprehensive engineering technology degree focusing on software engineering, electronics, embedded systems, robotics, control systems, and enterprise project leadership.',
      courses: [
        'Industrial Automation & PLC Systems (Ladder Logic & SCADA)',
        'Electronic Circuit Design & PCB Prototyping',
        'Microcontroller Systems & Robotics (STM32, PIC, AVR)',
        'Embedded Systems Engineering & Firmware',
        'Software Architecture & Full-Stack Systems',
        'Digital Signal Processing, Telemetry & Sensor Arrays'
      ]
    }
  ] as EducationItem[],

  skills: [
    // Web & Backend
    { name: 'PHP / Laravel', percentage: 95, category: 'web', categoryLabel: 'Web & Backend', level: 'Expert' },
    { name: '.NET / C#', percentage: 95, category: 'web', categoryLabel: 'Web & Backend', level: 'Expert' },
    { name: 'AngularJS / Angular', percentage: 95, category: 'web', categoryLabel: 'Web & Backend', level: 'Expert' },
    { name: 'Vue.js', percentage: 95, category: 'web', categoryLabel: 'Web & Backend', level: 'Expert' },
    { name: 'Python / Django REST', percentage: 95, category: 'web', categoryLabel: 'Web & Backend', level: 'Expert' },
    { name: 'MySQL / Relational DBs', percentage: 95, category: 'web', categoryLabel: 'Web & Backend', level: 'Expert' },
    { name: 'WordPress Development', percentage: 90, category: 'web', categoryLabel: 'Web & Backend', level: 'Advanced' },
    { name: 'Node.js & Express', percentage: 85, category: 'web', categoryLabel: 'Web & Backend', level: 'Proficient' },
    { name: 'React & Vite', percentage: 85, category: 'web', categoryLabel: 'Web & Backend', level: 'Proficient' },

    // Software & Systems
    { name: 'Python Engineering', percentage: 95, category: 'software', categoryLabel: 'Software & Automation', level: 'Expert' },
    { name: 'C# / Desktop Applications', percentage: 95, category: 'software', categoryLabel: 'Software & Automation', level: 'Expert' },
    { name: 'Java / Enterprise OOP', percentage: 95, category: 'software', categoryLabel: 'Software & Automation', level: 'Expert' },
    { name: 'Selenium Browser Automation', percentage: 95, category: 'software', categoryLabel: 'Software & Automation', level: 'Expert' },
    { name: 'Git, CI/CD & Workflows', percentage: 90, category: 'software', categoryLabel: 'Software & Automation', level: 'Advanced' },

    // Mobile
    { name: 'Flutter & Dart', percentage: 95, category: 'mobile', categoryLabel: 'Mobile Apps', level: 'Expert' },
    { name: 'Ionic 3 / Hybrid Apps', percentage: 95, category: 'mobile', categoryLabel: 'Mobile Apps', level: 'Expert' },

    // 3D & Design
    { name: 'Adobe Photoshop', percentage: 95, category: 'design', categoryLabel: '3D & Creative Design', level: 'Mastery' },
    { name: 'Adobe Illustrator', percentage: 95, category: 'design', categoryLabel: '3D & Creative Design', level: 'Mastery' },
    { name: 'Adobe After Effects', percentage: 95, category: 'design', categoryLabel: '3D & Creative Design', level: 'Mastery' },
    { name: 'Premiere Pro', percentage: 95, category: 'design', categoryLabel: '3D & Creative Design', level: 'Mastery' },
    { name: 'CorelDraw', percentage: 95, category: 'design', categoryLabel: '3D & Creative Design', level: 'Mastery' },
    { name: 'Blender 3D Modeling', percentage: 90, category: 'design', categoryLabel: '3D & Creative Design', level: 'Advanced' },
    { name: '3ds Max', percentage: 85, category: 'design', categoryLabel: '3D & Creative Design', level: 'Proficient' },
    { name: 'ZBrush Sculpting', percentage: 85, category: 'design', categoryLabel: '3D & Creative Design', level: 'Proficient' },

    // Cloud & Infrastructure
    { name: 'Cloud Services (AWS, GCP, Azure)', percentage: 85, category: 'cloud', categoryLabel: 'Cloud & DevOps', level: 'Proficient' },
    { name: 'Docker & Containerization', percentage: 82, category: 'cloud', categoryLabel: 'Cloud & DevOps', level: 'Proficient' },

    // Automation & PLC
    { name: 'PLC Programming (Siemens S7, TIA Portal)', percentage: 92, category: 'plc', categoryLabel: 'Automation & PLC', level: 'Advanced' },
    { name: 'Ladder Logic (LD) & Structured Text (ST)', percentage: 94, category: 'plc', categoryLabel: 'Automation & PLC', level: 'Expert' },
    { name: 'SCADA Systems & HMI Interface Design', percentage: 90, category: 'plc', categoryLabel: 'Automation & PLC', level: 'Advanced' },
    { name: 'Industrial Fieldbus & Protocols (Modbus, Profinet, CAN)', percentage: 90, category: 'plc', categoryLabel: 'Automation & PLC', level: 'Advanced' },
    { name: 'Industrial Sensors, Actuators & Relay Logic', percentage: 93, category: 'plc', categoryLabel: 'Automation & PLC', level: 'Expert' },
    { name: 'VFD & Motor Drive Speed Control', percentage: 88, category: 'plc', categoryLabel: 'Automation & PLC', level: 'Advanced' },

    // Electronics & Hardware Engineering
    { name: 'PCB Schematic Design & Routing (Altium, KiCad)', percentage: 92, category: 'electronics', categoryLabel: 'Electronics Engineering', level: 'Advanced' },
    { name: 'Microcontrollers (STM32, ESP32, PIC, Arduino)', percentage: 95, category: 'electronics', categoryLabel: 'Electronics Engineering', level: 'Expert' },
    { name: 'Circuit Testing, Oscilloscopes & Multimeter Debugging', percentage: 95, category: 'electronics', categoryLabel: 'Electronics Engineering', level: 'Mastery' },
    { name: 'Embedded C / C++ Firmware Development', percentage: 93, category: 'electronics', categoryLabel: 'Electronics Engineering', level: 'Expert' },
    { name: 'SMD Soldering, Rework & Hardware Prototyping', percentage: 94, category: 'electronics', categoryLabel: 'Electronics Engineering', level: 'Expert' },
    { name: 'Power Electronics, Voltage Regulators & Signal Conditioning', percentage: 89, category: 'electronics', categoryLabel: 'Electronics Engineering', level: 'Advanced' }
  ] as SkillItem[],

  projects: [
    {
      id: 'proj-1',
      title: 'Uniface Social Media Platform',
      category: 'software',
      categoryLabel: 'Full-Stack Web',
      subtitle: 'Modern Scalable Social Ecosystem',
      summary:
        'A full-stack social networking web application engineered with modular service architecture, reactive feeds, user authentication, and interactive media streaming.',
      fullDescription:
        'Uniface Social Media was architected to demonstrate a high-concurrency modern web portal. Built with a responsive frontend and resilient backend services, it features dynamic post streams, media upload handling, instant commenting, real-time notifications, and rich user profiles.',
      tags: ['React', 'TypeScript', 'Node.js', 'MySQL', 'REST API', 'Tailwind CSS'],
      image: '/src/assets/images/project_uniface_web_1790260962231.jpg',
      featured: true,
      date: 'May 2019 – Present',
      githubUrl: 'https://github.com/nuwanprasanna',
      highlights: [
        'Modular micro-component architecture with sub-second page transitions',
        'Secure token authentication and role-based permissions',
        'Optimized responsive feed rendering with lazy-loaded media assets'
      ]
    },
    {
      id: 'proj-2',
      title: '"Benefactor" Air Quality Detector',
      category: 'iot',
      categoryLabel: 'IoT & Hardware',
      subtitle: 'Environmental Telemetry & Sensing System',
      summary:
        'Hardware prototype and embedded firmware system for real-time atmospheric particulate monitoring, OLED sensor telemetry, and cloud data logging.',
      fullDescription:
        'Developed as an advanced engineering prototype during research and technology exhibitions (collaborating with engineering techniques honed at Vega Innovations and J\'Pura Tech). The Benefactor unit samples air pollutants, CO2, and temperature, projecting telemetry onto an onboard OLED screen and dispatching data via Wi-Fi.',
      tags: ['Embedded C++', 'Microcontroller', 'IoT Sensors', 'OLED Display', 'PCB Design', 'Telemetry'],
      image: '/src/assets/images/project_iot_airdetector_1790260932137.jpg',
      featured: true,
      date: '2019 – 2020',
      highlights: [
        'Real-time particulate matter (PM2.5 / PM10) detection and air quality indexing',
        'Low-power microcontroller firmware routines with automated sensor calibration',
        'Showcased at academic exhibitions and national innovation forums'
      ]
    },
    {
      id: 'proj-plc-1',
      title: 'Industrial PLC Automated Conveyor & Sorting Cell',
      category: 'plc',
      categoryLabel: 'Automation & PLC',
      subtitle: 'Siemens S7-1200 / TIA Portal & SCADA Station',
      summary:
        'Engineered an industrial automation sorting cell featuring Siemens S7 PLC ladder logic, Modbus TCP telemetry, pneumatic actuators, optical sensors, and real-time HMI supervisory interface.',
      fullDescription:
        'Designed during engineering technology practicals at the Faculty of Technology, Uni of Sri Jayewardenepura. Developed comprehensive IEC 61131-3 Ladder Logic (LD) and Structured Text (ST) routines for automated material verification, reject gating, fault trip interlocking, and live SCADA diagnostic monitoring.',
      tags: ['Siemens S7-1200', 'TIA Portal', 'Ladder Logic', 'SCADA / HMI', 'Industrial Automation', 'Modbus TCP', 'Pneumatics'],
      image: '/src/assets/images/plc_electronics_lab_1790262491862.jpg',
      featured: true,
      date: '2020',
      highlights: [
        'Deterministic ladder logic scan cycle with failsafe emergency E-stop interlocks',
        'Direct integration with inductive proximity, photoelectric sensors, and pneumatic solenoids',
        'Telemetry dashboard linking live process metrics via Modbus TCP protocols'
      ]
    },
    {
      id: 'proj-electronics-2',
      title: 'Precision Multi-Channel Sensor PCB & Telemetry Board',
      category: 'electronics',
      categoryLabel: 'Electronics Engineering',
      subtitle: 'Custom KiCad PCB Schematic, Signal Conditioning & Microcontroller',
      summary:
        'Custom 2-layer printed circuit board integrating ESP32 / STM32 microcontroller units, precision analog front-end op-amp filters, low-dropout voltage regulators, and CAN/I2C communication buses.',
      fullDescription:
        'Synthesizes practical electronic engineering experience gathered at Vega Innovations and undergraduate robotics laboratories. Designed schematic and PCB layouts with strict ground plane isolation, ESD protection diodes, and signal conditioning for low-noise sensor data acquisition in automotive and industrial environments.',
      tags: ['PCB Design', 'KiCad', 'STM32 / ESP32', 'Signal Conditioning', 'Oscilloscope Debugging', 'SMD Soldering'],
      image: '/src/assets/images/project_iot_airdetector_1790260932137.jpg',
      featured: true,
      date: '2019 – 2020',
      highlights: [
        'Optimized EMI/EMC trace routing with decoupled 3.3V / 5V linear power rails',
        'Oscilloscope waveform analysis to eliminate high-frequency switching noise and transients',
        'Hand-soldered 0805 SMD component packages and QFN ICs with hot-air rework station'
      ]
    },
    {
      id: 'proj-3',
      title: 'Blender 3D Cyber Mech & Hard-Surface Modeling',
      category: 'design',
      categoryLabel: '3D Design',
      subtitle: 'High-Poly Sci-Fi Robotics & PBR Shading',
      summary:
        'Intricate 3D robotic mechanical asset modeled in Blender featuring complex joint articulation, PBR weathered materials, and cinematic Octane-style studio lighting.',
      fullDescription:
        'Demonstrates mastery over Blender 3D modeling pipelines, including non-destructive modifier stacks, boolean cleanup, UV unwrapping, procedural surface imperfections, and emissive lighting compositing. Used for game assets and visual effects.',
      tags: ['Blender 3D', 'Octane Render', 'Hard-Surface Modeling', 'PBR Shading', 'ZBrush'],
      image: '/src/assets/images/project_blender_3d_1790260947796.jpg',
      featured: true,
      date: '2020 – Present',
      highlights: [
        'Precision topology with custom bevel weights and normal map baking',
        'Procedural grunge and micro-scratch metallic shaders',
        'Cinematic 8K multi-pass studio lighting composition'
      ]
    },
    {
      id: 'proj-4',
      title: 'ChordifyHub & EzChords Mobile App',
      category: 'mobile',
      categoryLabel: 'Mobile App',
      subtitle: 'Cross-Platform Guitar Chords & Transposer',
      summary:
        'Cross-platform Flutter application and companion web service providing guitar chord transpositions, interactive chord diagrams, and lyric sheets.',
      fullDescription:
        'Created for guitarists and music enthusiasts, ChordifyHub and EzChords parse raw song notations into interactive chord charts with key transposition (+/- semitones), auto-scrolling lyrics, and offline song saving via local SQLite storage.',
      tags: ['Flutter', 'Dart', 'SQLite', 'Music Tech', 'Android', 'iOS'],
      image: '/src/assets/images/project_uniface_web_1790260962231.jpg',
      featured: false,
      date: '2021 – Present',
      githubUrl: 'https://github.com/nuwanprasanna/chordifyhub',
      highlights: [
        'Instant musical key transposition engine running client-side',
        'Clean, finger-friendly chord fingering charts with alternate tunings',
        'Over 1,000+ songs indexed with instant client search'
      ]
    },
    {
      id: 'proj-5',
      title: 'Notekokka Productivity Mobile App',
      category: 'mobile',
      categoryLabel: 'Mobile App',
      subtitle: 'Lightweight Markdown Note Organizer',
      summary:
        'Responsive mobile notebook application with category tagging, markdown preview, full-text search, and encrypted local backup storage.',
      fullDescription:
        'Engineered to give users an instant, distraction-free writing environment on mobile devices. Supports rich-text markdown parsing, color-coded categorization, pin-to-top priority, and JSON export/import.',
      tags: ['Flutter', 'Dart', 'State Management', 'Markdown', 'SQLite'],
      image: '/src/assets/images/project_uniface_web_1790260962231.jpg',
      featured: false,
      date: '2020',
      highlights: [
        'Zero-latency keystroke markdown renderer with syntax highlighting',
        'Local SQLite database with instant query indexing',
        'Clean minimalist dark-mode user interface'
      ]
    },
    {
      id: 'proj-6',
      title: 'Sinhala OCR Neural Recognition Research',
      category: 'research',
      categoryLabel: 'IEEE Research Publication',
      subtitle: 'IEEE Xplore Published Research (Document: 10688954)',
      summary:
        'Peer-reviewed machine learning research published on IEEE Xplore detailing a deep learning computer vision pipeline to segment, extract, and recognize printed Sinhala character ligatures with high classification accuracy.',
      fullDescription:
        'Published in IEEE Xplore (Document ID: 10688954). This research tackles complex Sinhala typographic orthography, compound consonants, and diacritics using sophisticated morphological image filtering, character contour segmentation, and deep convolutional neural networks. Includes benchmarking against historical prints and multi-font newspapers.',
      tags: ['IEEE Xplore', 'Deep Learning', 'Computer Vision', 'Sinhala OCR', 'Neural Networks', 'Python', 'OpenCV'],
      image: '/src/assets/images/ieee_publication_card_1790263523164.jpg',
      featured: true,
      date: '2024 (IEEE Published)',
      githubUrl: 'https://github.com/nuwanprasanna/Sinhala-OCR-_Recognized_Text',
      publicationUrl: 'https://ieeexplore.ieee.org/document/10688954',
      liveUrl: 'https://ieeexplore.ieee.org/document/10688954',
      highlights: [
        'Officially indexed and peer-reviewed in the IEEE Xplore Digital Library (Doc ID: 10688954)',
        'Addresses challenging conjunct consonants, vowel modifiers, and font variance in Sinhala script',
        'Achieved state-of-the-art character segmentation and optical recognition metrics'
      ]
    },
    {
      id: 'proj-7',
      title: 'Automated YouTube Pipeline with Python',
      category: 'software',
      categoryLabel: 'Automation Bot',
      subtitle: 'Headless Video Metadata & Upload Engine',
      summary:
        'Intelligent Python automation utility that batches, formats, tags, and automatically uploads scheduled video content using Selenium and YouTube Data API v3.',
      fullDescription:
        'Streamlines multi-channel YouTube workflows for content creation channels (Idea Infinity, Woow Look). Handles batch thumbnail attaching, auto-generated SEO tags, description formatting, and scheduled publishing.',
      tags: ['Python', 'Selenium', 'YouTube API', 'Web Scraping', 'Automation'],
      image: '/src/assets/images/project_uniface_web_1790260962231.jpg',
      featured: false,
      date: '2019 – Present',
      highlights: [
        'Headless Chrome browser driver with session preservation and 2FA support',
        'Automated tag enrichment and video description templating',
        'Reduced manual video publishing overhead by over 80%'
      ]
    },
    {
      id: 'proj-8',
      title: 'Twitch Overlays, Motion & Stream Graphics',
      category: 'design',
      categoryLabel: 'Creative Design',
      subtitle: 'Dynamic Broadcast Identity Systems',
      summary:
        'Comprehensive animated broadcast packages featuring custom alerts, webcam frames, stream transition stingers, and emote sets.',
      fullDescription:
        'Designed for high-profile Twitch and YouTube gaming creators. Uses Adobe After Effects for motion graphics rendered into lightweight WebM alpha formats, accompanied by vector emote stickers created in Illustrator.',
      tags: ['After Effects', 'Illustrator', 'Motion Graphics', 'Streaming Tech', 'Photoshop'],
      image: '/src/assets/images/project_blender_3d_1790260947796.jpg',
      featured: false,
      date: '2020 – Present',
      highlights: [
        'Alpha-channel transparent motion transitions with sound sync',
        'Pixel-perfect vector badge and emote sets adhering to platform specifications',
        'Shipped over 50+ bespoke streamer packages with top creator reviews'
      ]
    }
  ] as ProjectItem[],

  exhibitions: [
    {
      id: 'ex-1',
      title: 'Thirasara Lanka National Exhibition',
      year: '2017',
      venue: 'BMICH, Colombo',
      role: 'Technology Exhibitor',
      description:
        'Demonstrated sustainable engineering innovations and university technology research before national industry leaders and ministerial delegates at the BMICH convention center.',
      badge: 'National Convention'
    },
    {
      id: 'ex-2',
      title: 'Infotel 2018 Innovation Pavilion',
      year: '2018',
      venue: 'BMICH, Colombo',
      role: 'Hardware & IoT Innovator',
      description:
        'Showcased cutting-edge student engineering prototypes, sensor telemetry hardware, and smart connected devices in the prestigious Infotel Innovation Pavilion.',
      badge: 'Premier ICT Expo'
    },
    {
      id: 'ex-3',
      title: 'J\'PURA TECH TALKS 2018',
      year: '2018',
      venue: 'University of Sri Jayewardenepura',
      role: 'Speaker & Presenter',
      description:
        'Presented technical lectures on emerging technology stacks, rapid prototyping with 3D design, and cross-platform software methodologies to undergraduate engineering students.',
      badge: 'Technical Speaker'
    },
    {
      id: 'ex-4',
      title: 'Musaeus College ENVISAGE \'18 & Devi Balika Exhibitions',
      year: '2018',
      venue: 'Colombo, Sri Lanka',
      role: 'Engineering Mentor & Demonstrator',
      description:
        'Mentored aspiring students and displayed practical robotics, sensor integration, and visual computing projects at top collegiate science symposiums.',
      badge: 'STEM Exhibition'
    },
    {
      id: 'ex-5',
      title: 'Vega Innovations EVX Supercar Project Showcase',
      year: '2019 – 2020',
      venue: 'Vega R&D Facility & Automotive Forums',
      role: 'Trainee Electronic Systems Contributor',
      description:
        'Contributed to electronic testing, wire loom diagnostics, and telemetry analysis for the Vega EVX all-electric supercar, putting South Asia on the global electric mobility map.',
      badge: 'EV Pioneering'
    }
  ] as ExhibitionItem[],

  publications: [
    {
      id: 'pub-1',
      title: 'Deep Learning & Morphological Segmentation for Sinhala Optical Character Recognition',
      authors: 'Nuwan Prasanna et al.',
      venue: 'IEEE Xplore Digital Library / IEEE International Conference',
      year: '2024',
      documentId: '10688954',
      url: 'https://ieeexplore.ieee.org/document/10688954',
      doi: '10.1109/IEEExplore.10688954',
      abstract:
        'Addresses challenging typography, character ligatures, and diacritic marks in the Sinhala language using advanced morphological image pre-processing, contour-based glyph segmentation, and deep convolutional neural networks (CNNs). Evaluated across standard public newspaper archives and historical prints.',
      tags: ['IEEE Xplore', 'Computer Vision', 'Deep Learning', 'Sinhala OCR', 'Neural Networks', 'Document Processing'],
      category: 'Peer-Reviewed Conference'
    }
  ] as PublicationItem[]
};
