import React, { useState } from 'react';
import { CV_DATA, ProjectItem } from '../data/cvData';
import { ArrowUpRight, Code, Cpu, Smartphone, Box, Terminal, ExternalLink } from 'lucide-react';

interface ProjectsSectionProps {
  onSelectProject: (project: ProjectItem) => void;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({ onSelectProject }) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const filterOptions = [
    { id: 'all', label: 'All Projects' },
    { id: 'research', label: 'IEEE Research' },
    { id: 'plc', label: 'PLC & Automation' },
    { id: 'electronics', label: 'Electronics & Hardware' },
    { id: 'software', label: 'Full-Stack & Web' },
    { id: 'iot', label: 'IoT & Telemetry' },
    { id: 'mobile', label: 'Mobile Apps' },
    { id: 'design', label: '3D & Motion' },
  ];

  const filteredProjects =
    activeFilter === 'all'
      ? CV_DATA.projects
      : CV_DATA.projects.filter((p) => p.category === activeFilter);

  return (
    <section id="projects" className="py-20 border-t border-slate-800/80 bg-[#060a12] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <div className="text-xs font-mono text-cyan-400 tracking-wider">04. ENGINEERING & DESIGN PORTFOLIO</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
              Selected Works & Case Studies
            </h2>
            <p className="text-slate-400 max-w-xl text-base">
              A curated selection of software systems, embedded IoT hardware prototypes, mobile utilities, and 3D computer graphics.
            </p>
          </div>

          {/* Segmented Filter Control */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            {filterOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => setActiveFilter(opt.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  activeFilter === opt.id
                    ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => onSelectProject(project)}
              className="group rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-cyan-500/50 transition-all duration-300 overflow-hidden flex flex-col cursor-pointer"
            >
              {/* Image Preview Slot */}
              <div className="relative aspect-video w-full bg-slate-950 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                  onError={(e) => {
                    // Graceful visual fallback
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
                
                {/* Visual Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />

                {/* Unboxed Metadata Overlay */}
                <div className="absolute top-3 left-3 text-[11px] font-mono text-cyan-300 drop-shadow">
                  {project.categoryLabel}
                </div>

                <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="flex items-center gap-1 px-2 py-1 bg-cyan-500 text-slate-950 text-xs font-semibold rounded font-sans shadow">
                    <span>Inspect</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>

              {/* Card Body (Lead directly with title, no badge sandwich) */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-1.5">
                  <h3 className="font-display text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                    {project.title}
                  </h3>
                  <div className="text-xs font-mono text-slate-400">
                    {project.subtitle}
                  </div>
                  <p className="text-slate-300 text-xs leading-relaxed line-clamp-3 pt-1">
                    {project.summary}
                  </p>
                </div>

                {/* Tech Tags - Clean unboxed text with dot separators */}
                <div className="pt-3 border-t border-slate-800/60 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-400 font-mono">
                  {project.tags.slice(0, 4).map((tag, tIdx) => (
                    <React.Fragment key={tag}>
                      <span className="text-slate-300">{tag}</span>
                      {tIdx < Math.min(project.tags.length, 4) - 1 && (
                        <span className="text-slate-700">·</span>
                      )}
                    </React.Fragment>
                  ))}
                  {project.tags.length > 4 && (
                    <span className="text-slate-500">+{project.tags.length - 4}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* GitHub External Repository Callout */}
        <div className="mt-12 p-6 rounded-xl bg-slate-900/40 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-sm font-semibold text-white">More Source Code & Projects on GitHub</div>
            <div className="text-xs text-slate-400">
              Repositories include ChordifyHub, Sinhala OCR ML models, CI/CD workflows, and Flutter apps.
            </div>
          </div>

          <a
            href={CV_DATA.profile.socials.github}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 px-4 py-2 text-xs font-mono text-cyan-400 border border-cyan-500/30 rounded-md hover:bg-cyan-500/10 transition-colors whitespace-nowrap"
          >
            <span>github.com/nuwanprasanna</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

      </div>
    </section>
  );
};
