import React, { useState } from 'react';
import { Download, FileText, Check, Code, FileCode, Printer, ExternalLink, X, Archive, FolderArchive } from 'lucide-react';
import { CV_DATA } from '../data/cvData';

interface DownloadCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPrintResume: () => void;
}

export const DownloadCenterModal: React.FC<DownloadCenterModalProps> = ({
  isOpen,
  onClose,
  onOpenPrintResume,
}) => {
  const [downloadedItem, setDownloadedItem] = useState<string | null>(null);

  if (!isOpen) return null;

  const downloadFiles = [
    {
      id: 'zip-all',
      name: 'Nuwan_Prasanna_Digital_CV_Full_Project.zip',
      title: 'Full Project Source Code (.ZIP)',
      description: 'Complete codebase package containing React, Vite, Tailwind CSS, high-res lab assets, PLC & Electronics data, and components ready to run with npm install.',
      format: 'ZIP Archive',
      size: '3.4 MB',
      url: '/downloads/Nuwan_Prasanna_Digital_CV_Full_Project.zip',
      icon: FolderArchive,
      actionType: 'download',
      badge: 'Recommended',
    },
    {
      id: 'targz-all',
      name: 'Nuwan_Prasanna_Digital_CV_Full_Project.tar.gz',
      title: 'Full Source Code Archive (.TAR.GZ)',
      description: 'Linux / Unix compressed tarball containing the entire project tree and source files.',
      format: 'TAR.GZ',
      size: '3.4 MB',
      url: '/downloads/Nuwan_Prasanna_Digital_CV_Full_Project.tar.gz',
      icon: Archive,
      actionType: 'download',
    },
    {
      id: 'pdf-ats',
      name: 'Nuwan_Prasanna_CV_Print.pdf',
      title: 'Digital CV (PDF / Print-Ready)',
      description: 'Standard 2-page ATS formatted curriculum vitae with complete PLC, electronics, software, education, and skill metrics.',
      format: 'PDF / Print',
      size: 'A4 Vector',
      icon: Printer,
      actionType: 'print',
    },
    {
      id: 'txt',
      name: 'Nuwan_Prasanna_CV.txt',
      title: 'Plain Text Resume (.TXT)',
      description: 'Clean ASCII plain text document including PLC automation and electronics skills for ATS and text parsers.',
      format: 'Plain Text',
      size: '7.0 KB',
      url: '/downloads/Nuwan_Prasanna_CV.txt',
      icon: FileText,
      actionType: 'download',
    },
    {
      id: 'markdown',
      name: 'Nuwan_Prasanna_CV.md',
      title: 'Markdown Resume (.MD)',
      description: 'GitHub-flavored markdown version with heading hierarchy, PLC automation, circuit design, and project breakdowns.',
      format: 'Markdown',
      size: '4.9 KB',
      url: '/downloads/Nuwan_Prasanna_CV.md',
      icon: FileCode,
      actionType: 'download',
    },
    {
      id: 'json',
      name: 'Nuwan_Prasanna_Profile.json',
      title: 'Structured Profile Data (.JSON)',
      description: 'Machine-readable JSON schema containing structured engineer data, PLC proficiencies, PCB skills, links, and hardware projects.',
      format: 'JSON Schema',
      size: '3.6 KB',
      url: '/downloads/Nuwan_Prasanna_Profile.json',
      icon: Code,
      actionType: 'download',
    },
  ];

  const handleDownloadClick = (item: typeof downloadFiles[0]) => {
    if (item.actionType === 'print') {
      onClose();
      onOpenPrintResume();
      return;
    }

    if (item.url) {
      const anchor = document.createElement('a');
      anchor.href = item.url;
      anchor.download = item.name;
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);

      setDownloadedItem(item.id);
      setTimeout(() => setDownloadedItem(null), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#090d16] border border-slate-700/90 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0c1220]">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
              <Download className="w-3.5 h-3.5" />
              <span>FILE EXPORT & DOWNLOAD CENTER</span>
            </div>
            <h3 className="font-display text-lg font-bold text-white tracking-tight">
              Download Nuwan Prasanna's Curriculum Vitae
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close download modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* File Cards List */}
        <div className="p-6 overflow-y-auto space-y-4">
          <p className="text-xs text-slate-400">
            Select your preferred file format for Nuwan Prasanna's CV and technical portfolio records. All assets are generated directly from verified credentials.
          </p>

          <div className="grid grid-cols-1 gap-3">
            {downloadFiles.map((file) => {
              const Icon = file.icon;
              const isDownloaded = downloadedItem === file.id;

              return (
                <div
                  key={file.id}
                  className="p-4 rounded-lg bg-slate-900/70 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 shrink-0 mt-0.5 sm:mt-0 group-hover:bg-cyan-500/20 transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-white text-sm group-hover:text-cyan-300 transition-colors">
                          {file.title}
                        </span>
                        {file.badge && (
                          <span className="text-[10px] font-mono text-cyan-950 bg-cyan-400 font-bold px-1.5 py-0.5 rounded">
                            {file.badge}
                          </span>
                        )}
                        <span className="text-[11px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700/60">
                          {file.size}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed max-w-md">
                        {file.description}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 self-end sm:self-center">
                    <button
                      onClick={() => handleDownloadClick(file)}
                      className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-md transition-colors shadow-sm cursor-pointer whitespace-nowrap ${
                        isDownloaded
                          ? 'bg-emerald-500 text-slate-950'
                          : 'bg-cyan-400 hover:bg-cyan-300 text-slate-950'
                      }`}
                    >
                      {isDownloaded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Downloaded!</span>
                        </>
                      ) : file.actionType === 'print' ? (
                        <>
                          <Printer className="w-3.5 h-3.5" />
                          <span>Print / Save PDF</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" />
                          <span>Download {file.format}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick info note */}
          <div className="mt-4 p-3.5 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400 font-mono flex items-center justify-between">
            <span className="text-slate-300">Target Contact: nuwanekanayaka6@gmail.com</span>
            <span className="text-cyan-400 font-semibold">+94 754899858</span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-[#0c1220] border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-500">
          <span>Encoding: UTF-8</span>
          <button
            onClick={onClose}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Close [ESC]
          </button>
        </div>

      </div>
    </div>
  );
};
