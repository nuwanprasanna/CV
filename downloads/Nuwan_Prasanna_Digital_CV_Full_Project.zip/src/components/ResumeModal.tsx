import React from 'react';
import { CV_DATA } from '../data/cvData';
import { X, Printer, Download, Mail, Phone, MapPin, ExternalLink, Github, FileText, Code } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDownloads?: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, onOpenDownloads }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadTxt = () => {
    const a = document.createElement('a');
    a.href = '/downloads/Nuwan_Prasanna_CV.txt';
    a.download = 'Nuwan_Prasanna_CV.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/90 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Action Bar */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-slate-950 border-b border-slate-800 select-none print:hidden">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-white text-sm">
              Official Digital CV Document · Nuwan Prasanna
            </span>
            <span className="hidden sm:inline-block text-xs font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/60">
              ATS-Optimized View
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {onOpenDownloads && (
              <button
                onClick={() => {
                  onClose();
                  onOpenDownloads();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 text-xs font-medium rounded transition-colors cursor-pointer"
                title="Download other formats (.txt, .md, .json)"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Export Files</span>
              </button>
            )}

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-xs font-semibold rounded transition-colors cursor-pointer"
              title="Print or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close CV preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Resume Container */}
        <div className="p-6 sm:p-10 overflow-y-auto bg-white text-slate-900 font-sans print:p-0 print:m-0 print:text-black">
          
          {/* Header Block */}
          <div className="border-b-2 border-slate-900 pb-5 mb-6">
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
              <div>
                <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display">
                  {CV_DATA.profile.name}
                </h1>
                <div className="text-base font-semibold text-slate-700 mt-0.5">
                  Software Engineer & Creative Technologist · B.Eng. Tech (Hons)
                </div>
              </div>
              <div className="text-xs text-slate-600 text-left sm:text-right font-mono space-y-0.5">
                <div>{CV_DATA.profile.location}</div>
                <div>{CV_DATA.profile.phones.join(' · ')}</div>
                <div className="font-medium text-slate-900">{CV_DATA.profile.email}</div>
                <div>github.com/nuwanprasanna</div>
              </div>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="mb-6 space-y-1.5">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Professional Summary
            </h2>
            <p className="text-xs text-slate-700 leading-relaxed">
              Bachelor of Engineering Technology (Honours) graduate from the Faculty of Technology, University of Sri Jayewardenepura. Offers 5+ years of combined experience across full-stack enterprise web development (.NET, C#, Python, React, Vue, Flutter, Laravel), 3D spatial modeling (Blender 3D, 3ds Max, ZBrush), and electronic hardware telemetry from industrial training at Vega Innovations (Pvt) Ltd.
            </p>
          </div>

          {/* Core Technical Stacks */}
          <div className="mb-6 space-y-2">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Technical Competencies
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
              <div>
                <strong className="text-slate-900">Automation & PLC:</strong>{' '}
                <span className="text-slate-700">Siemens S7 (TIA Portal), Ladder Logic (LD), Structured Text (ST), SCADA, HMI, Modbus TCP, Profinet, Industrial Sensors & Actuators</span>
              </div>
              <div>
                <strong className="text-slate-900">Electronics & Embedded:</strong>{' '}
                <span className="text-slate-700">PCB Schematic Design (KiCad, Altium), STM32, ESP32, PIC, Oscilloscope Diagnostics, Embedded C/C++, SMD Soldering & Prototyping</span>
              </div>
              <div>
                <strong className="text-slate-900">Web & Backend:</strong>{' '}
                <span className="text-slate-700">.NET Core, C#, PHP/Laravel, Python/Django REST, React, Vue.js, Angular, Node.js, MySQL</span>
              </div>
              <div>
                <strong className="text-slate-900">Mobile & 3D Design:</strong>{' '}
                <span className="text-slate-700">Flutter, Dart, Blender 3D, 3ds Max, ZBrush, Adobe Photoshop, Illustrator, After Effects, Selenium Automation</span>
              </div>
            </div>
          </div>

          {/* Work Experience */}
          <div className="mb-6 space-y-3">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Work History
            </h2>

            {CV_DATA.experiences.map((exp) => (
              <div key={exp.id} className="space-y-1">
                <div className="flex justify-between items-baseline text-xs">
                  <div>
                    <strong className="text-slate-900 text-sm">{exp.role}</strong>{' '}
                    <span className="text-slate-600">| {exp.company} ({exp.location})</span>
                  </div>
                  <span className="font-mono text-slate-600 text-[11px]">{exp.period}</span>
                </div>
                <p className="text-xs text-slate-700 leading-snug">{exp.description}</p>
                <ul className="list-disc list-inside text-xs text-slate-600 space-y-0.5 pl-1">
                  {exp.achievements.map((ach, i) => (
                    <li key={i}>{ach}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Education */}
          <div className="mb-6 space-y-2">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Education & Honors
            </h2>
            {CV_DATA.education.map((edu) => (
              <div key={edu.id} className="text-xs space-y-0.5">
                <div className="flex justify-between items-baseline">
                  <div>
                    <strong className="text-slate-900 text-sm">{edu.degree}</strong>{' '}
                    <span className="text-slate-600">| {edu.institution}</span>
                  </div>
                  <span className="font-mono text-slate-600 text-[11px]">{edu.period}</span>
                </div>
                <p className="text-slate-700">{edu.details}</p>
                <div className="text-[11px] text-slate-600">
                  <strong>Key Modules:</strong> {edu.courses.join(', ')}
                </div>
              </div>
            ))}
          </div>

          {/* Selected Projects */}
          <div className="mb-6 space-y-2">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Key Engineering Projects
            </h2>
            <div className="space-y-2 text-xs">
              <div>
                <strong className="text-slate-900">Industrial PLC Automated Sorting Cell:</strong> Siemens S7-1200 / TIA Portal ladder logic & Structured Text routine with pneumatic reject gating, failsafe E-stop interlocks, and live SCADA diagnostic dashboard.
              </div>
              <div>
                <strong className="text-slate-900">Precision Multi-Channel Sensor PCB:</strong> Custom 2-layer KiCad PCB integrating STM32/ESP32, low-noise op-amp filters, and CAN bus for industrial and automotive telemetry.
              </div>
              <div>
                <strong className="text-slate-900">Uniface Social Media:</strong> Full-stack social portal with reactive feed architecture, authentication, and media storage (.NET / React / MySQL).
              </div>
              <div>
                <strong className="text-slate-900">"Benefactor" Air Quality Sensor:</strong> Real-time hardware telemetry and OLED environmental particulate monitor tested during Vega Innovations internship.
              </div>
              <div>
                <strong className="text-slate-900">ChordifyHub & EzChords:</strong> Cross-platform Flutter mobile music application for instant key transposition and chord diagrams.
              </div>
            </div>
          </div>

          {/* Research Publications */}
          <div className="mb-6 space-y-2">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Peer-Reviewed Scientific Publications
            </h2>
            <div className="space-y-1.5 text-xs">
              <div>
                <div className="font-semibold text-slate-900">
                  Deep Learning & Morphological Segmentation for Sinhala Optical Character Recognition
                </div>
                <div className="text-slate-600 font-mono text-[11px]">
                  <strong>IEEE Xplore Digital Library</strong> · Document ID: 10688954 · Published 2024
                </div>
                <div className="text-slate-700 mt-0.5">
                  Peer-reviewed machine learning research addressing Sinhala typography and character ligatures using contour segmentation and deep CNN classifiers.
                  Link: <span className="font-mono text-slate-900 underline">https://ieeexplore.ieee.org/document/10688954</span>
                </div>
              </div>
            </div>
          </div>

          {/* Exhibitions & Outreach */}
          <div className="space-y-1 text-xs">
            <h2 className="text-xs font-bold font-mono tracking-wider uppercase text-slate-900 border-b border-slate-300 pb-1">
              Exhibitions & Industry Forums
            </h2>
            <div className="text-slate-700 space-y-0.5">
              <div>• <strong>Thirasara Lanka Exhibition (2017):</strong> BMICH Colombo — Technology Exhibitor</div>
              <div>• <strong>Infotel Innovation Pavilion (2018):</strong> BMICH Colombo — Hardware & IoT Innovator</div>
              <div>• <strong>J'pura Tech Talks (2018):</strong> University of Sri Jayewardenepura — Technical Speaker</div>
              <div>• <strong>Vega EVX Supercar Project:</strong> Vega Innovations — Electronic systems testing participant</div>
            </div>
          </div>

        </div>

        {/* Modal Bottom Print Button */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400 print:hidden">
          <span>Ready for A4 / Letter format</span>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 text-cyan-400 hover:text-cyan-300 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Click to Print or Save PDF</span>
          </button>
        </div>

      </div>
    </div>
  );
};
