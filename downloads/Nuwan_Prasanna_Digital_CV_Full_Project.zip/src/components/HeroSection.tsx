import React, { useState } from 'react';
import { CV_DATA } from '../data/cvData';
import { ArrowRight, Copy, Check, Terminal, ExternalLink, Code2, Sparkles, Layers, Cpu, Download } from 'lucide-react';

interface HeroSectionProps {
  onOpenResume: () => void;
  onOpenTerminal: () => void;
  onOpenDownloads: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenResume, onOpenTerminal, onOpenDownloads }) => {
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(CV_DATA.profile.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2200);
  };

  return (
    <section id="intro" className="relative pt-12 pb-20 md:pt-20 md:pb-28 overflow-hidden tech-grid-pattern">
      <div className="absolute inset-0 tech-radial-glow pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Bold Typographic Hierarchy & Proof */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Unboxed Status Kicker */}
            <div className="flex items-center gap-2.5 text-xs font-mono text-cyan-400">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>{CV_DATA.profile.availability}</span>
              <span className="text-slate-600">/</span>
              <span className="text-slate-400">Colombo, Sri Lanka</span>
            </div>

            {/* Display Headline */}
            <div className="space-y-2">
              <h1 className="font-display text-4xl sm:text-6xl font-extrabold text-white tracking-tight leading-[1.08] max-w-2xl">
                Engineering <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-300">Scalable Systems</span> & 3D Visuals.
              </h1>
              <p className="text-lg sm:text-xl font-medium text-slate-300 font-sans">
                Nuwan Prasanna <span className="text-slate-500 font-normal">· Software Engineer & B.Eng. Tech (Hons)</span>
              </p>
            </div>

            {/* Core Narrative / Value Prop */}
            <p className="text-slate-400 text-base sm:text-lg leading-relaxed max-w-2xl">
              Graduate of the Faculty of Technology, University of Sri Jayewardenepura. Blending 5+ years of 
              high-concurrency software development (.NET, C#, React, Vue, Flutter, Python) with industrial 
              <strong className="text-slate-200 font-semibold"> PLC automation (Siemens S7, SCADA)</strong>, 
              <strong className="text-slate-200 font-semibold"> electronics engineering (PCB design, STM32/ESP32)</strong>, 
              and creative 3D spatial modeling.
            </p>

            {/* Action CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="#projects"
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-slate-950 bg-cyan-400 rounded-md hover:bg-cyan-300 transition-colors shadow-sm cursor-pointer"
              >
                <span>Explore Works</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <button
                onClick={onOpenResume}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-200 bg-slate-900 border border-slate-700/80 rounded-md hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
              >
                <span>View Full CV</span>
              </button>

              <button
                onClick={onOpenDownloads}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-cyan-300 bg-cyan-950/40 border border-cyan-800/70 rounded-md hover:bg-cyan-900/60 hover:text-white transition-colors cursor-pointer"
                title="Download CV files (.txt, .md, .json, pdf)"
              >
                <Download className="w-4 h-4 text-cyan-400" />
                <span>Download Files</span>
              </button>

              <button
                onClick={handleCopyEmail}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-mono text-slate-300 bg-slate-900/60 border border-slate-800 rounded-md hover:border-cyan-500/50 hover:text-cyan-300 transition-colors cursor-pointer"
                title="Click to copy email address"
              >
                {copiedEmail ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 text-xs font-sans">Copied to clipboard</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-xs">{CV_DATA.profile.email}</span>
                  </>
                )}
              </button>
            </div>

            {/* Quantitative Proof Adjacency */}
            <div className="pt-8 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4">
              {CV_DATA.profile.metrics.map((metric, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums tracking-tight">
                    {metric.value}
                  </div>
                  <div className="text-xs font-semibold text-slate-300">{metric.label}</div>
                  <div className="text-[11px] text-slate-500">{metric.sub}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Hero Visual Asset & Live Tech Terminal Card */}
          <div className="lg:col-span-5 flex flex-col items-center lg:items-end">
            <div className="relative w-full max-w-md">
              
              {/* Decorative Corner Framing */}
              <div className="absolute -top-2 -left-2 w-6 h-6 border-t-2 border-l-2 border-cyan-400/60 pointer-events-none z-20" />
              <div className="absolute -bottom-2 -right-2 w-6 h-6 border-b-2 border-r-2 border-cyan-400/60 pointer-events-none z-20" />

              {/* Main Image Container */}
              <div className="relative rounded-xl overflow-hidden border border-slate-800 bg-slate-900/90 shadow-2xl group">
                <img
                  src={CV_DATA.profile.avatar}
                  alt="Nuwan Prasanna - Software Engineer"
                  referrerPolicy="no-referrer"
                  className="w-full aspect-square object-cover object-center filter grayscale contrast-110 group-hover:grayscale-0 group-hover:contrast-100 transition-all duration-500"
                />
                
                {/* Gradient Scrim for Content Protection */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#070b14] via-transparent to-transparent opacity-80" />

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-0 inset-x-0 p-5 space-y-1 z-10">
                  <div className="flex items-center justify-between text-xs font-mono text-cyan-300">
                    <span className="flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5" />
                      <span>TECH ID: NP-1996</span>
                    </span>
                    <span className="text-slate-400">VERIFIED DEGREE</span>
                  </div>
                  <div className="text-sm font-semibold text-white">
                    Faculty of Technology · Uni of Sri Jayewardenepura
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2 flex-wrap">
                    <span>PLC & SCADA</span>
                    <span>·</span>
                    <span>Electronics & PCB</span>
                    <span>·</span>
                    <span>Full-Stack</span>
                    <span>·</span>
                    <span>Flutter</span>
                    <span>·</span>
                    <span>Blender 3D</span>
                  </div>
                </div>
              </div>

              {/* Quick Interactive Terminal Access Pill Button */}
              <div className="mt-4 flex items-center justify-between px-3 py-2 bg-slate-900/80 border border-slate-800 rounded-lg text-xs font-mono">
                <div className="flex items-center gap-2 text-slate-400">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>nuwan.profile.config</span>
                </div>
                <button
                  onClick={onOpenTerminal}
                  className="text-cyan-400 hover:text-cyan-300 font-sans hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Launch Inspector</span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
