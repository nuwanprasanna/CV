import React, { useState } from 'react';
import { CV_DATA, SkillItem } from '../data/cvData';
import { Code2, Palette, Smartphone, Terminal, Cloud, Layers, Cpu } from 'lucide-react';

export const SkillsSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Stacks' },
    { id: 'plc', label: 'Automation & PLC' },
    { id: 'electronics', label: 'Electronics & Circuits' },
    { id: 'web', label: 'Web & Backend' },
    { id: 'software', label: 'Software & Automation' },
    { id: 'mobile', label: 'Mobile Apps' },
    { id: 'design', label: '3D & Creative Design' },
    { id: 'cloud', label: 'Cloud & Infrastructure' },
  ];

  const filteredSkills =
    selectedCategory === 'all'
      ? CV_DATA.skills
      : CV_DATA.skills.filter((s) => s.category === selectedCategory);

  return (
    <section id="skills" className="py-20 border-t border-slate-800/80 bg-[#070b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <div className="text-xs font-mono text-cyan-400 tracking-wider">03. TECHNICAL PROFICIENCY</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
              Professional Skills & Mastery
            </h2>
            <p className="text-slate-400 max-w-xl text-base">
              Verified domain proficiencies honed through production client engagements, academic research, and freelance contracts.
            </p>
          </div>

          {/* Interactive Category Filter Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSkills.map((skill) => (
            <div
              key={skill.name}
              className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-white text-sm">{skill.name}</span>
                <span className="font-mono text-xs text-cyan-400 tabular-nums font-semibold">
                  {skill.percentage}%
                </span>
              </div>

              {/* Progress Bar with Cyan Accent */}
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mb-3">
                <div
                  className="h-full bg-gradient-to-r from-cyan-500 to-sky-400 rounded-full transition-all duration-700 ease-out"
                  style={{ width: `${skill.percentage}%` }}
                />
              </div>

              {/* Unboxed Metadata (Zero pills) */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1">
                <span>{skill.categoryLabel}</span>
                <span className="text-slate-400">{skill.level}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Creative Tech Callout */}
        <div className="mt-10 p-5 rounded-xl bg-slate-900/40 border border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">Full Software, PLC Automation & Electronics Lifecycle</div>
              <div className="text-xs text-slate-400">
                From Siemens PLC ladder logic & PCB oscilloscope diagnostics to Vega electric supercar telemetry and cloud-scale .NET/React applications.
              </div>
            </div>
          </div>

          <a
            href="#contact"
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 hover:underline shrink-0 flex items-center gap-1"
          >
            <span>Request technical interview</span>
            <span>→</span>
          </a>
        </div>

      </div>
    </section>
  );
};
