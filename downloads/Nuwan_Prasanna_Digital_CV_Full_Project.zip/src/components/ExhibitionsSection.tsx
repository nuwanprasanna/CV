import React from 'react';
import { CV_DATA } from '../data/cvData';
import { Award, Presentation, Calendar, MapPin, Sparkles } from 'lucide-react';

export const ExhibitionsSection: React.FC = () => {
  return (
    <section id="exhibitions" className="py-20 border-t border-slate-800/80 bg-[#070b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-12 space-y-2">
          <div className="text-xs font-mono text-cyan-400 tracking-wider">05. DEMONSTRATIONS & TALKS</div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Exhibitions, Summits & Outreach
          </h2>
          <p className="text-slate-400 max-w-2xl text-base">
            Showcasing hardware prototypes, embedded engineering innovations, and technical talks across national ICT expos and academic conventions.
          </p>
        </div>

        {/* Exhibitions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CV_DATA.exhibitions.map((item) => (
            <div
              key={item.id}
              className="p-6 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs font-mono text-cyan-400">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{item.year}</span>
                  </span>
                  <span className="text-slate-400">{item.badge}</span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {item.title}
                </h3>

                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-sans">
                  <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <span>{item.venue}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-300 font-medium">{item.role}</span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed pt-2">
                  {item.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono text-slate-500">
                <span>Verified Academic Milestone</span>
                <span className="text-cyan-400 font-semibold">Faculty of Technology</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
