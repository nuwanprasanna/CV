import React, { useState } from 'react';
import { CV_DATA } from '../data/cvData';
import { Terminal, Copy, Check, X, Maximize2, Minimize2 } from 'lucide-react';

interface TechTerminalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenResume: () => void;
  onOpenContact: () => void;
  onOpenDownloads?: () => void;
}

export const TechTerminal: React.FC<TechTerminalProps> = ({
  isOpen,
  onClose,
  onOpenResume,
  onOpenContact,
  onOpenDownloads,
}) => {
  const [activeTab, setActiveTab] = useState<'cli' | 'json' | 'stack'>('cli');
  const [inputCommand, setInputCommand] = useState('');
  const [history, setHistory] = useState<Array<{ cmd?: string; output: React.ReactNode }>>([
    {
      output: (
        <div className="space-y-1 text-slate-300">
          <div>Nuwan Prasanna Interactive Engineer Shell v2.4.0</div>
          <div className="text-slate-500">Type <span className="text-cyan-400 font-semibold">'help'</span> to see available commands or click tabs above.</div>
        </div>
      ),
    },
  ]);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = inputCommand.trim().toLowerCase();
    if (!cmd) return;

    let response: React.ReactNode;

    switch (cmd) {
      case 'help':
        response = (
          <div className="space-y-1 text-slate-300">
            <div className="text-cyan-400 font-semibold">Available Commands:</div>
            <div>• <span className="text-amber-300">bio</span> : Summary of Nuwan's background & education</div>
            <div>• <span className="text-amber-300">skills</span> : List primary engineering & 3D stacks</div>
            <div>• <span className="text-amber-300">contact</span> : Show phone, email, and social coordinates</div>
            <div>• <span className="text-amber-300">ieee</span> : View published IEEE research paper (Doc 10688954)</div>
            <div>• <span className="text-amber-300">download</span> : Download full project zip, tar.gz, txt, md, & json files</div>
            <div>• <span className="text-amber-300">resume</span> : Open digital printable CV dialog</div>
            <div>• <span className="text-amber-300">hire</span> : Open direct project inquiry form</div>
            <div>• <span className="text-amber-300">clear</span> : Clear console history</div>
          </div>
        );
        break;
      case 'bio':
        response = (
          <div className="text-slate-300 space-y-1">
            <div className="font-semibold text-white">Nuwan Prasanna · Software Engineer</div>
            <div>Degree: B.Eng. Tech (Hons), University of Sri Jayewardenepura (2016-2020)</div>
            <div>5+ Years crafting dynamic software (.NET, C#, Python, React, Vue, Flutter) & 3D visual assets.</div>
          </div>
        );
        break;
      case 'skills':
        response = (
          <div className="text-slate-300 space-y-1">
            <div>Automation & PLC: Siemens S7, TIA Portal (92%), Ladder Logic & ST (94%), SCADA & HMI (90%), Modbus/Profinet (90%)</div>
            <div>Electronics & Hardware: PCB KiCad/Altium (92%), STM32/ESP32 (95%), Oscilloscope Debugging (95%), Firmware C/C++ (93%)</div>
            <div>Web/Backend: .NET, Laravel, React, Vue, Python/Django, MySQL (95%)</div>
            <div>Mobile: Flutter & Dart (95%), Ionic 3 (95%)</div>
            <div>Design & 3D: Blender 3D (90%), Photoshop (95%), After Effects (95%), ZBrush (85%)</div>
            <div>Software & Automation: Selenium, Python Automation, CI/CD pipelines (95%)</div>
          </div>
        );
        break;
      case 'contact':
        response = (
          <div className="text-slate-300 space-y-1">
            <div>Email: <a href="mailto:nuwanekanayaka6@gmail.com" className="text-cyan-400 hover:underline">nuwanekanayaka6@gmail.com</a></div>
            <div>Mobile: +94 754899858 / +94 712718506</div>
            <div>Location: Rathpaha Niwasa, Perawella, Sri Lanka</div>
            <div>GitHub: <a href="https://github.com/nuwanprasanna" target="_blank" rel="noreferrer" className="text-cyan-400 hover:underline">github.com/nuwanprasanna</a></div>
          </div>
        );
        break;
      case 'ieee':
      case 'paper':
      case 'research':
      case 'publication':
        response = (
          <div className="text-slate-300 space-y-1.5 border-l-2 border-cyan-400 pl-3">
            <div className="font-semibold text-white"># IEEE Xplore Peer-Reviewed Research Publication</div>
            <div className="text-cyan-400">Title: Deep Learning & Morphological Segmentation for Sinhala Optical Character Recognition</div>
            <div>Status: Published & Indexed in IEEE Xplore Digital Library</div>
            <div>Document Identifier: <span className="font-mono text-amber-300 font-bold">10688954</span></div>
            <div>DOI / URL: <a href="https://ieeexplore.ieee.org/document/10688954" target="_blank" rel="noreferrer" className="text-cyan-300 hover:underline break-all">https://ieeexplore.ieee.org/document/10688954</a></div>
          </div>
        );
        break;
      case 'download':
      case 'downloads':
      case 'files':
        if (onOpenDownloads) {
          onOpenDownloads();
          response = <div className="text-cyan-400">Launching File Export & Download Center...</div>;
        } else {
          response = <div className="text-slate-300">Download files available via /downloads/ directory.</div>;
        }
        break;
      case 'resume':
      case 'cv':
        onOpenResume();
        response = <div className="text-emerald-400">Opening Digital CV Dialog...</div>;
        break;
      case 'hire':
        onOpenContact();
        response = <div className="text-emerald-400">Directing to Contact Inquiry Form...</div>;
        break;
      case 'clear':
        setHistory([]);
        setInputCommand('');
        return;
      default:
        response = (
          <div className="text-rose-400">
            Command not recognized: '{cmd}'. Type <span className="text-white underline">help</span> for command directory.
          </div>
        );
    }

    setHistory((prev) => [...prev, { cmd: inputCommand, output: response }]);
    setInputCommand('');
  };

  const jsonDump = JSON.stringify(
    {
      engineer: CV_DATA.profile.name,
      credentials: CV_DATA.profile.degree,
      specialization: ['Full-Stack .NET & Laravel', 'Flutter Mobile Systems', 'Blender 3D Modeling', 'IoT Sensors & Firmware'],
      contact: {
        primaryEmail: CV_DATA.profile.email,
        directMobile: CV_DATA.profile.phones,
        base: CV_DATA.profile.location
      },
      verifiedExperience: CV_DATA.experiences.map((e) => ({
        company: e.company,
        role: e.role,
        period: e.period,
        focus: e.skills
      }))
    },
    null,
    2
  );

  const copyJson = () => {
    navigator.clipboard.writeText(jsonDump);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-[#090d16] border border-slate-700/80 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        
        {/* Terminal Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d1322] border-b border-slate-800 select-none">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            <span className="ml-2 text-xs font-mono text-slate-400 flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>developer@nuwan-terminal: ~</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors cursor-pointer"
              title="Close Terminal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 px-4 py-2 bg-[#090e1a] border-b border-slate-800/80 text-xs font-mono">
          <button
            onClick={() => setActiveTab('cli')}
            className={`px-3 py-1 rounded transition-colors cursor-pointer ${
              activeTab === 'cli' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            console.sh
          </button>
          <button
            onClick={() => setActiveTab('json')}
            className={`px-3 py-1 rounded transition-colors cursor-pointer ${
              activeTab === 'json' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            profile.json
          </button>
          <button
            onClick={() => setActiveTab('stack')}
            className={`px-3 py-1 rounded transition-colors cursor-pointer ${
              activeTab === 'stack' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            tech_matrix.yaml
          </button>

          {activeTab === 'json' && (
            <button
              onClick={copyJson}
              className="ml-auto flex items-center gap-1 text-[11px] text-slate-400 hover:text-white cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
          )}
        </div>

        {/* Content Pane */}
        <div className="p-4 overflow-y-auto font-mono text-xs leading-relaxed flex-1 space-y-3 bg-[#050811] text-slate-300">
          {activeTab === 'cli' && (
            <div className="space-y-3">
              {history.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  {item.cmd && (
                    <div className="flex items-center gap-2 text-cyan-400">
                      <span className="text-emerald-400">nuwan@root:~$</span>
                      <span>{item.cmd}</span>
                    </div>
                  )}
                  <div className="pl-4">{item.output}</div>
                </div>
              ))}

              {/* Live Command Line Input */}
              <form onSubmit={handleCommand} className="flex items-center gap-2 pt-2 border-t border-slate-800/60">
                <span className="text-emerald-400 select-none">nuwan@root:~$</span>
                <input
                  type="text"
                  value={inputCommand}
                  onChange={(e) => setInputCommand(e.target.value)}
                  placeholder="type 'help', 'skills', 'contact', 'resume'..."
                  className="flex-1 bg-transparent border-none outline-none text-white font-mono placeholder:text-slate-600"
                  autoFocus
                />
              </form>
            </div>
          )}

          {activeTab === 'json' && (
            <pre className="text-emerald-300/90 whitespace-pre overflow-x-auto selection:bg-cyan-500/40">
              {jsonDump}
            </pre>
          )}

          {activeTab === 'stack' && (
            <div className="space-y-4">
              <div className="text-cyan-400 font-semibold"># Core Architectural Competencies</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-900/50 p-3 rounded border border-slate-800">
                  <div className="text-cyan-400 font-semibold mb-2">Industrial Automation & PLC</div>
                  <ul className="space-y-1 text-slate-400">
                    <li>• Siemens S7-1200 / TIA Portal (92%)</li>
                    <li>• Ladder Logic (LD) & Structured Text (ST) (94%)</li>
                    <li>• SCADA & HMI Supervisory Stations (90%)</li>
                    <li>• Modbus TCP, Profinet & Industrial CAN (90%)</li>
                    <li>• Relay Interlocking & Sensor Arrays (93%)</li>
                  </ul>
                </div>
                <div className="bg-slate-900/50 p-3 rounded border border-slate-800">
                  <div className="text-emerald-400 font-semibold mb-2">Electronics & Embedded Engineering</div>
                  <ul className="space-y-1 text-slate-400">
                    <li>• PCB Schematic & Routing (KiCad, Altium) (92%)</li>
                    <li>• STM32, ESP32, PIC, AVR Microcontrollers (95%)</li>
                    <li>• Oscilloscope & Logic Analyzer Testing (95%)</li>
                    <li>• Embedded C/C++ Firmware Development (93%)</li>
                    <li>• SMD Soldering & Hot-Air Rework (94%)</li>
                  </ul>
                </div>
                <div className="bg-slate-900/50 p-3 rounded border border-slate-800">
                  <div className="text-amber-300 font-semibold mb-2">Full-Stack Web & Backend</div>
                  <ul className="space-y-1 text-slate-400">
                    <li>• C# & .NET Core / ASP.NET MVC (95%)</li>
                    <li>• PHP & Laravel Framework (95%)</li>
                    <li>• Angular & AngularJS (95%)</li>
                    <li>• Vue.js & React Frontend (90%)</li>
                    <li>• Python & Django REST Framework (95%)</li>
                    <li>• MySQL & Relational DB Systems (95%)</li>
                  </ul>
                </div>
                <div className="bg-slate-900/50 p-3 rounded border border-slate-800">
                  <div className="text-purple-300 font-semibold mb-2">3D, Mobile & Software</div>
                  <ul className="space-y-1 text-slate-400">
                    <li>• Flutter & Dart Mobile Apps (95%)</li>
                    <li>• Blender 3D Hard-Surface Modeling (90%)</li>
                    <li>• Adobe Photoshop & Illustrator (95%)</li>
                    <li>• After Effects & Motion Design (95%)</li>
                    <li>• Selenium Browser & Script Automation (95%)</li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Terminal Footer */}
        <div className="px-4 py-2 bg-[#090e1a] border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-500">
          <span>Session: active (UTC)</span>
          <div className="flex items-center gap-3">
            <button onClick={onOpenResume} className="hover:text-cyan-400 underline cursor-pointer">
              Launch PDF Resume
            </button>
            <button onClick={onClose} className="hover:text-white cursor-pointer">
              Exit Terminal [ESC]
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
