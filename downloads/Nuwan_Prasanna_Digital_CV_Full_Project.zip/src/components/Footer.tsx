import React from 'react';
import { CV_DATA } from '../data/cvData';
import { ArrowUp, Github, Facebook, Globe, Youtube, Terminal, FileText, Download } from 'lucide-react';

interface FooterProps {
  onOpenResume: () => void;
  onOpenTerminal: () => void;
  onOpenDownloads: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenResume, onOpenTerminal, onOpenDownloads }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050811] border-t border-slate-800/80 py-12 text-slate-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Brand & Credentials */}
          <div className="space-y-1 text-center md:text-left">
            <div className="font-display font-bold text-white text-base">
              Nuwan Prasanna <span className="text-cyan-400 font-mono text-xs font-normal">/ B.Eng Tech (Hons)</span>
            </div>
            <div className="text-slate-500 font-sans">
              Software Engineer & Creative Technologist · Colombo, Sri Lanka
            </div>
          </div>

          {/* Quick Jump Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-slate-400 font-medium">
            <a href="#about" className="hover:text-white transition-colors">About</a>
            <a href="#experience" className="hover:text-white transition-colors">Experience</a>
            <a href="#skills" className="hover:text-white transition-colors">Skills</a>
            <a href="#projects" className="hover:text-white transition-colors">Portfolio</a>
            <a href="#exhibitions" className="hover:text-white transition-colors">Exhibitions</a>
            <a href="#contact" className="hover:text-white transition-colors">Contact</a>
            <button
              onClick={onOpenTerminal}
              className="hover:text-cyan-400 transition-colors flex items-center gap-1 font-mono cursor-pointer"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Shell</span>
            </button>
            <button
              onClick={onOpenResume}
              className="hover:text-cyan-400 transition-colors flex items-center gap-1 font-mono cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Resume</span>
            </button>
            <button
              onClick={onOpenDownloads}
              className="hover:text-cyan-400 transition-colors flex items-center gap-1 font-mono cursor-pointer text-cyan-300"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Downloads</span>
            </button>
          </div>

          {/* Scroll to Top */}
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white rounded-md border border-slate-800 transition-colors cursor-pointer"
            title="Scroll back to top"
          >
            <ArrowUp className="w-4 h-4" />
            <span className="font-mono text-[11px]">Top</span>
          </button>
        </div>

        {/* Social Links & Copyright */}
        <div className="pt-6 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 font-mono text-[11px]">
          <div>
            &copy; {new Date().getFullYear()} Nuwan Prasanna. All rights reserved.
          </div>

          <div className="flex items-center gap-4 flex-wrap">
            <a
              href={CV_DATA.profile.socials.ieee}
              target="_blank"
              rel="noreferrer"
              className="text-cyan-300 hover:text-white font-semibold transition-colors"
            >
              IEEE Xplore (Doc 10688954)
            </a>
            <span>/</span>
            <a
              href={CV_DATA.profile.socials.github}
              target="_blank"
              rel="noreferrer"
              className="hover:text-cyan-400 transition-colors"
            >
              GitHub
            </a>
            <span>/</span>
            <a
              href={CV_DATA.profile.socials.facebook}
              target="_blank"
              rel="noreferrer"
              className="hover:text-cyan-400 transition-colors"
            >
              Facebook
            </a>
            <span>/</span>
            <a
              href={CV_DATA.profile.socials.ezbugfix}
              target="_blank"
              rel="noreferrer"
              className="hover:text-cyan-400 transition-colors"
            >
              ezbugfix.com
            </a>
            <span>/</span>
            <a
              href={CV_DATA.profile.socials.goldchords}
              target="_blank"
              rel="noreferrer"
              className="hover:text-cyan-400 transition-colors"
            >
              goldchords
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
};
