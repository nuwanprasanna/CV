import React, { useState } from 'react';
import { CV_DATA, ExperienceItem, EducationItem } from '../data/cvData';
import { Briefcase, GraduationCap, Calendar, MapPin, CheckCircle2, ChevronRight } from 'lucide-react';

export const ExperienceSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'experience' | 'education'>('all');

  return (
    <section id="experience" className="py-20 border-t border-slate-800/80 bg-[#060a12] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="space-y-2">
            <div className="text-xs font-mono text-cyan-400 tracking-wider">02. CAREER & ACADEMIA</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
              Experience & Education
            </h2>
            <p className="text-slate-400 max-w-xl text-base">
              Chronological track record spanning high-concurrency software development, electric vehicle telemetry, and formal engineering education.
            </p>
          </div>

          {/* Segmented Filter Control (Allowed per frontend-design skill) */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg shrink-0">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Milestones
            </button>
            <button
              onClick={() => setActiveTab('experience')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'experience'
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Work Experience
            </button>
            <button
              onClick={() => setActiveTab('education')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                activeTab === 'education'
                  ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Degree & Studies
            </button>
          </div>
        </div>

        {/* Timeline List */}
        <div className="space-y-6">
          {(activeTab === 'all' || activeTab === 'experience') &&
            CV_DATA.experiences.map((item, idx) => (
              <div
                key={item.id}
                className="p-6 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all group"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-3">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>{item.company}</span>
                      <span className="text-slate-600">/</span>
                      <span className="text-slate-400">{item.location}</span>
                      <span className="text-slate-600">/</span>
                      <span className="text-slate-400">{item.type}</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mt-1 group-hover:text-cyan-300 transition-colors">
                      {item.role}
                    </h3>
                  </div>

                  <div className="text-xs font-mono text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/50 shrink-0 self-start">
                    {item.period}
                  </div>
                </div>

                <p className="text-slate-300 text-sm leading-relaxed mb-4">
                  {item.description}
                </p>

                {/* Achievements Bullet List */}
                <div className="space-y-1.5 mb-4">
                  {item.achievements.map((ach, aIdx) => (
                    <div key={aIdx} className="flex items-start gap-2 text-xs text-slate-400">
                      <ChevronRight className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{ach}</span>
                    </div>
                  ))}
                </div>

                {/* Tech Tags - Zero-pill unboxed text with subtle separator */}
                <div className="pt-3 border-t border-slate-800/60 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="text-slate-500 font-mono text-[11px]">Core Tech:</span>
                  {item.skills.map((skill, sIdx) => (
                    <React.Fragment key={skill}>
                      <span className="text-slate-300 font-mono">{skill}</span>
                      {sIdx < item.skills.length - 1 && <span className="text-slate-700">·</span>}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            ))}

          {(activeTab === 'all' || activeTab === 'education') &&
            CV_DATA.education.map((edu) => (
              <div
                key={edu.id}
                className="p-6 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 transition-all group"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-3">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>{edu.institution}</span>
                      <span className="text-slate-600">/</span>
                      <span className="text-slate-400">{edu.location}</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mt-1 group-hover:text-amber-300 transition-colors">
                      {edu.degree}
                    </h3>
                  </div>

                  <div className="text-xs font-mono text-slate-400 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/50 shrink-0 self-start">
                    {edu.period}
                  </div>
                </div>

                <p className="text-slate-300 text-sm leading-relaxed mb-4">
                  {edu.details}
                </p>

                {/* Course Modules */}
                <div className="space-y-1.5 mb-2">
                  <div className="text-xs font-semibold text-slate-400">Primary Curricular Specializations:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1">
                    {edu.courses.map((course, cIdx) => (
                      <div key={cIdx} className="flex items-center gap-2 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{course}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
        </div>

      </div>
    </section>
  );
};
