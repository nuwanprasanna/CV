import React, { useState } from 'react';
import { CV_DATA } from '../data/cvData';
import { Mail, Phone, MapPin, Send, Paperclip, Check, AlertCircle, Copy, ExternalLink, RefreshCw, Sparkles } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('fullstack');
  const [budget, setBudget] = useState('standard');
  const [message, setMessage] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedFormPayload, setCopiedFormPayload] = useState(false);

  const categories = [
    { id: 'plc_automation', label: 'Industrial Automation, PLC Programming & SCADA' },
    { id: 'electronics_pcb', label: 'Electronics Engineering, PCB Design & Firmware' },
    { id: 'fullstack', label: 'Full-Stack Web (.NET, Laravel, React, Vue)' },
    { id: 'mobile', label: 'Mobile App Development (Flutter, Dart)' },
    { id: 'design3d', label: '3D Modeling & Motion Graphics (Blender)' },
    { id: 'iot', label: 'Embedded IoT & Telemetry Sensor Arrays' },
    { id: 'automation', label: 'Python Automation & Web Scraping' },
    { id: 'consultation', label: 'Technical Architecture & Engineering Advisory' },
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      setAttachedFiles((prev) => [...prev, ...filesArray]);
    }
  };

  const removeFile = (index: number) => {
    setAttachedFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;

    setIsSubmitting(true);
    // Simulate high-tech network dispatch
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 900);
  };

  const handleDirectMailto = () => {
    const selectedCatLabel = categories.find((c) => c.id === category)?.label || 'Engineering Inquiry';
    const subject = encodeURIComponent(`Project Inquiry: ${selectedCatLabel} - ${name || 'Client'}`);
    const body = encodeURIComponent(
      `Hello Nuwan,\n\nName: ${name}\nEmail: ${email}\nCategory: ${selectedCatLabel}\nBudget/Scope: ${budget}\n\nProject Details:\n${message}\n\n---\nSent via Nuwan Prasanna Digital CV Portal`
    );
    window.location.href = `mailto:${CV_DATA.profile.email}?subject=${subject}&body=${body}`;
  };

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(CV_DATA.profile.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleCopyFormPayload = () => {
    const payload = `Name: ${name}\nEmail: ${email}\nCategory: ${category}\nMessage:\n${message}`;
    navigator.clipboard.writeText(payload);
    setCopiedFormPayload(true);
    setTimeout(() => setCopiedFormPayload(false), 2000);
  };

  const resetForm = () => {
    setName('');
    setEmail('');
    setMessage('');
    setAttachedFiles([]);
    setSubmitted(false);
  };

  return (
    <section id="contact" className="py-20 border-t border-slate-800/80 bg-[#060a12] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-12 space-y-2">
          <div className="text-xs font-mono text-cyan-400 tracking-wider">06. INITIATE TRANSMISSION</div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Contact & Collaboration
          </h2>
          <p className="text-slate-400 max-w-2xl text-base">
            Let's grab a coffee or jump on a call. Send an inquiry regarding full-stack software development, mobile apps, or 3D visual design.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Direct Contact Info Coordinates */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="p-6 rounded-xl bg-slate-900/70 border border-slate-800/90 space-y-6">
              <div>
                <h3 className="text-lg font-bold text-white font-display">Direct Channels</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Prompt replies within 24 hours. Available across UTC+5:30 and international time zones.
                </p>
              </div>

              {/* Email Card with 1-Click Copy */}
              <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1.5 text-cyan-400 font-mono">
                    <Mail className="w-3.5 h-3.5" />
                    <span>DIRECT INBOX</span>
                  </span>
                  <button
                    onClick={handleCopyEmail}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-cyan-400 cursor-pointer font-mono"
                  >
                    {copiedEmail ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedEmail ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="text-sm font-mono font-medium text-white break-all">
                  <a href={`mailto:${CV_DATA.profile.email}`} className="hover:text-cyan-400 transition-colors">
                    {CV_DATA.profile.email}
                  </a>
                </div>
              </div>

              {/* Phone Contacts */}
              <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono text-cyan-400">
                  <Phone className="w-3.5 h-3.5" />
                  <span>VOICE & WHATSAPP</span>
                </div>
                <div className="space-y-1 text-sm font-mono text-white">
                  <div>
                    <a href="tel:+94754899858" className="hover:text-cyan-400 transition-colors">
                      +94 754899858 <span className="text-xs text-slate-500 font-sans">(Primary)</span>
                    </a>
                  </div>
                  <div>
                    <a href="tel:+94712718506" className="hover:text-cyan-400 transition-colors">
                      (+9471) 271-8506 <span className="text-xs text-slate-500 font-sans">(Alternative)</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Location Coordinates */}
              <div className="p-4 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono text-cyan-400">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>RESIDENCE & WORKSPACE</span>
                </div>
                <div className="text-sm text-slate-200">
                  {CV_DATA.profile.location}
                </div>
                <div className="text-xs text-slate-500">
                  Perawella / Colombo, Western Province, Sri Lanka
                </div>
              </div>

              {/* Social Repositories */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">Connected Networks</div>
                <div className="flex flex-wrap gap-2 text-xs font-mono">
                  <a
                    href={CV_DATA.profile.socials.github}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700/60 transition-colors"
                  >
                    GitHub
                  </a>
                  <a
                    href={CV_DATA.profile.socials.facebook}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700/60 transition-colors"
                  >
                    Facebook
                  </a>
                  <a
                    href={CV_DATA.profile.socials.ezbugfix}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700/60 transition-colors"
                  >
                    ezbugfix.com
                  </a>
                  <a
                    href={CV_DATA.profile.socials.goldchords}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700/60 transition-colors"
                  >
                    goldchords.blogspot
                  </a>
                </div>
              </div>

            </div>

          </div>

          {/* Right Column: High-Tech Email Transmission Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-xl bg-slate-900/80 border border-slate-800/90 shadow-xl">
              
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
                    <span className="font-display font-semibold text-white text-base">
                      Send Project Request
                    </span>
                    <span className="text-[11px] font-mono text-cyan-400">
                      RFC-5322 SECURE DISPATCH
                    </span>
                  </div>

                  {/* Name and Email Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-slate-400">
                        Full Name <span className="text-cyan-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Alex Morgan"
                        className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700 rounded-lg text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400 transition-colors"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-mono text-slate-400">
                        Email Address <span className="text-cyan-400">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="client@organization.com"
                        className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700 rounded-lg text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400 transition-colors"
                      />
                    </div>
                  </div>

                  {/* Category Selection */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-400">
                      Engagement Category <span className="text-cyan-400">*</span>
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-cyan-400 transition-colors"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Message Input */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-mono text-slate-400">
                      Project Scope & Specifications <span className="text-cyan-400">*</span>
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Describe your technical requirements, goals, timeline, or inquiries..."
                      className="w-full px-3.5 py-2.5 bg-slate-950/80 border border-slate-700 rounded-lg text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400 transition-colors resize-y"
                    />
                  </div>

                  {/* File Attachment Support */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                      <span className="flex items-center gap-1.5">
                        <Paperclip className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Add Attachment (.pdf, .doc, .zip)</span>
                      </span>
                      <span className="text-[11px] text-slate-500">Optional</span>
                    </div>

                    <label className="flex items-center justify-center gap-2 px-4 py-3 bg-slate-950/40 border border-dashed border-slate-700 rounded-lg hover:border-cyan-500/60 cursor-pointer transition-colors text-xs text-slate-400 hover:text-slate-200">
                      <input
                        type="file"
                        multiple
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      <span>Click to upload project brief or specification documents</span>
                    </label>

                    {attachedFiles.length > 0 && (
                      <div className="space-y-1 pt-1">
                        {attachedFiles.map((file, fIdx) => (
                          <div
                            key={fIdx}
                            className="flex items-center justify-between px-2.5 py-1 bg-slate-800/60 rounded text-xs font-mono text-slate-300"
                          >
                            <span className="truncate max-w-[280px]">{file.name}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-slate-500 text-[10px]">
                                {(file.size / 1024).toFixed(1)} KB
                              </span>
                              <button
                                type="button"
                                onClick={() => removeFile(fIdx)}
                                className="text-rose-400 hover:text-rose-300 cursor-pointer"
                              >
                                ×
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Submission Row with Direct Mail Option */}
                  <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleDirectMailto}
                      className="text-xs font-mono text-slate-400 hover:text-cyan-400 transition-colors flex items-center gap-1.5 cursor-pointer order-2 sm:order-1"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Launch in Default Mail Client</span>
                    </button>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 text-sm font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors shadow-sm disabled:opacity-50 cursor-pointer order-1 sm:order-2"
                    >
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Transmitting...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Send Message</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              ) : (
                /* Transmission Success State */
                <div className="py-8 space-y-6 text-center animate-in fade-in duration-300">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                    <Check className="w-6 h-6" />
                  </div>

                  <div className="space-y-1">
                    <h3 className="text-xl font-bold text-white font-display">Transmission Dispatched Successfully</h3>
                    <p className="text-sm text-slate-300 max-w-md mx-auto">
                      Thank you, <span className="text-white font-semibold">{name}</span>. Your project request has been logged. Nuwan will reach back at <span className="text-cyan-400 font-mono">{email}</span>.
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-slate-950/80 border border-slate-800 text-left max-w-lg mx-auto text-xs font-mono space-y-1.5 text-slate-400">
                    <div className="text-slate-500 uppercase tracking-wider text-[10px]">Transmission Summary</div>
                    <div>Category: {categories.find((c) => c.id === category)?.label}</div>
                    <div className="line-clamp-2">Excerpt: "{message}"</div>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      onClick={handleDirectMailto}
                      className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-mono cursor-pointer"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Also Open in Email App</span>
                    </button>

                    <button
                      onClick={handleCopyFormPayload}
                      className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-mono cursor-pointer"
                    >
                      {copiedFormPayload ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedFormPayload ? 'Copied' : 'Copy Message Text'}</span>
                    </button>

                    <button
                      onClick={resetForm}
                      className="px-4 py-2 bg-cyan-400 text-slate-950 font-semibold rounded text-xs hover:bg-cyan-300 cursor-pointer"
                    >
                      Send Another Inquiry
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
