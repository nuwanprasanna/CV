import React from 'react';
import { ProjectItem } from '../data/cvData';
import { X, ExternalLink, Github, CheckCircle, Calendar, Tag, BookOpen } from 'lucide-react';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#090d16] border border-slate-700/90 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0c1220]">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
            <span>{project.categoryLabel}</span>
            <span className="text-slate-600">/</span>
            <span className="text-slate-400">{project.date}</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* Media Container with Zero-Broken-Image Fallback */}
          <div className="relative aspect-video rounded-lg overflow-hidden bg-slate-900 border border-slate-800">
            <img
              src={project.image}
              alt={project.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              onError={(e) => {
                // styled fallback container
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>

          {/* Title & Subtitle */}
          <div>
            <h3 className="font-display text-2xl font-bold text-white tracking-tight">
              {project.title}
            </h3>
            <div className="text-sm font-mono text-cyan-400 mt-0.5">
              {project.subtitle}
            </div>
          </div>

          {/* Deep Architectural Breakdown */}
          <div className="space-y-3 text-slate-300 text-sm leading-relaxed">
            <div className="text-xs font-mono text-slate-500 uppercase tracking-wider">Project Architecture & Overview</div>
            <p>{project.fullDescription}</p>
          </div>

          {/* Key Deliverables & Highlights */}
          <div className="space-y-2">
            <div className="text-xs font-mono text-slate-500 uppercase tracking-wider">Key Highlights & Invariants</div>
            <div className="space-y-1.5">
              {project.highlights.map((h, i) => (
                <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                  <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{h}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tech Stack Metadata - Zero Pills */}
          <div className="pt-3 border-t border-slate-800/80">
            <div className="text-xs font-mono text-slate-500 uppercase tracking-wider mb-2">Technologies Deployed</div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-slate-300 font-mono">
              {project.tags.map((tag, idx) => (
                <React.Fragment key={tag}>
                  <span className="text-cyan-300">{tag}</span>
                  {idx < project.tags.length - 1 && <span className="text-slate-700">·</span>}
                </React.Fragment>
              ))}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#0c1220] border-t border-slate-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3 flex-wrap">
            {project.publicationUrl && (
              <a
                href={project.publicationUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs font-mono text-cyan-950 bg-cyan-400 hover:bg-cyan-300 px-3.5 py-1.5 rounded font-semibold transition-colors shadow-sm"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>View on IEEE Xplore (Doc 10688954)</span>
                <ExternalLink className="w-3 h-3 ml-0.5" />
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs font-mono text-slate-300 hover:text-white bg-slate-900 border border-slate-700 px-3 py-1.5 rounded hover:bg-slate-800 transition-colors"
              >
                <Github className="w-3.5 h-3.5" />
                <span>Repository</span>
              </a>
            )}
            {project.liveUrl && !project.publicationUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-xs font-mono text-slate-950 bg-cyan-400 hover:bg-cyan-300 px-3 py-1.5 rounded font-medium transition-colors"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Live Portal</span>
              </a>
            )}
          </div>

          <button
            onClick={onClose}
            className="text-xs font-mono text-slate-400 hover:text-white cursor-pointer"
          >
            Close [ESC]
          </button>
        </div>

      </div>
    </div>
  );
};
