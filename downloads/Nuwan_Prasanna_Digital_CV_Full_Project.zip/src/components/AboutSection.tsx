import React from 'react';
import { CV_DATA } from '../data/cvData';
import { User, Calendar, Mail, Phone, MapPin, Globe, Youtube, GraduationCap, Award, Compass, BookOpen, ExternalLink } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 border-t border-slate-800/80 bg-[#070b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="mb-12 space-y-2">
          <div className="text-xs font-mono text-cyan-400 tracking-wider">01. PROFILE & PERSONA</div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            About Me
          </h2>
          <p className="text-slate-400 max-w-2xl text-base">
            Bridging rigorous engineering principles with high-impact 3D visual communication and robust software architectures.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Main Bio Text */}
          <div className="lg:col-span-7 space-y-6">
            <div className="text-slate-300 space-y-4 text-base sm:text-lg leading-relaxed font-sans">
              <p>
                Hello! I am a <strong className="text-white font-semibold">Software Engineer</strong> and a graduate of the <strong className="text-white font-semibold">Bachelor of Engineering Technology (Honours)</strong> program at the Faculty of Technology, University of Sri Jayewardenepura.
              </p>
              <p className="text-slate-400 text-base">
                With a unique blend of <strong className="text-slate-200">5+ years of creative expertise</strong> in 3D modeling, animation, and graphic design, alongside robust software development skills, I bring a sharp eye for UI/UX to every technical project. I have hands-on experience managing the complete lifecycle of dynamic applications—specializing in full-stack ecosystems including <span className="text-cyan-300">C#, .NET, Java, React, Vue.js, Angular, and Flutter</span>.
              </p>
              <p className="text-slate-400 text-base">
                Backed by hands-on engineering exposure at <strong className="text-slate-200">Vega Innovations (Pvt) Ltd</strong>—South Asia’s first electric supercar pioneer—I combine electronic testing, sensor telemetry integration, and low-level firmware testing with enterprise web applications and mobile digital products.
              </p>
            </div>

            {/* Academic & Professional Highlights Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-4">
              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-cyan-400 text-sm font-semibold">
                  <GraduationCap className="w-4 h-4" />
                  <span>Engineering Degree</span>
                </div>
                <div className="text-sm font-medium text-white">B.Eng. Tech (Hons)</div>
                <div className="text-xs text-slate-400">
                  Faculty of Technology, University of Sri Jayewardenepura (2016–2020)
                </div>
              </div>

              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold">
                  <Award className="w-4 h-4" />
                  <span>PLC & Electronics</span>
                </div>
                <div className="text-sm font-medium text-white">Industrial Automation</div>
                <div className="text-xs text-slate-400">
                  Siemens S7, TIA Portal, PCB design, STM32 firmware, and Vega EV telemetry.
                </div>
              </div>

              <div className="p-4 rounded-lg bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 text-sm font-semibold">
                  <Compass className="w-4 h-4" />
                  <span>Creative & 3D</span>
                </div>
                <div className="text-sm font-medium text-white">5+ Years Visuals</div>
                <div className="text-xs text-slate-400">
                  Blender 3D, After Effects, Photoshop, and UI/UX design systems.
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Particulars & Web Properties */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Direct Bio Coordinates (No pills, clean unboxed list) */}
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800/90 space-y-4">
              <div className="text-xs font-mono text-slate-400 uppercase tracking-wider pb-2 border-b border-slate-800">
                Personal Particulars
              </div>

              <dl className="space-y-3 text-sm">
                <div className="flex justify-between items-start gap-4">
                  <dt className="text-slate-500 flex items-center gap-2 shrink-0">
                    <User className="w-4 h-4 text-slate-400" />
                    <span>Full Name</span>
                  </dt>
                  <dd className="font-medium text-slate-200 text-right">{CV_DATA.profile.name}</dd>
                </div>

                <div className="flex justify-between items-start gap-4">
                  <dt className="text-slate-500 flex items-center gap-2 shrink-0">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span>Birthday</span>
                  </dt>
                  <dd className="font-medium text-slate-200 text-right">{CV_DATA.profile.birthday}</dd>
                </div>

                <div className="flex justify-between items-start gap-4">
                  <dt className="text-slate-500 flex items-center gap-2 shrink-0">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span>Email</span>
                  </dt>
                  <dd className="font-mono text-cyan-400 text-right text-xs break-all">
                    <a href={`mailto:${CV_DATA.profile.email}`} className="hover:underline">
                      {CV_DATA.profile.email}
                    </a>
                  </dd>
                </div>

                <div className="flex justify-between items-start gap-4">
                  <dt className="text-slate-500 flex items-center gap-2 shrink-0">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span>Mobile</span>
                  </dt>
                  <dd className="font-mono text-slate-200 text-right text-xs space-y-0.5">
                    <div><a href="tel:+94754899858" className="hover:text-cyan-400">+94 754899858</a></div>
                    <div><a href="tel:+94712718506" className="hover:text-cyan-400">(+9471) 271-8506</a></div>
                  </dd>
                </div>

                <div className="flex justify-between items-start gap-4">
                  <dt className="text-slate-500 flex items-center gap-2 shrink-0">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    <span>Address</span>
                  </dt>
                  <dd className="text-slate-300 text-right text-xs">{CV_DATA.profile.location}</dd>
                </div>
              </dl>
            </div>

            {/* Blogs, Websites & Channels */}
            <div className="p-6 rounded-xl bg-slate-900/80 border border-slate-800/90 space-y-4">
              <div className="text-xs font-mono text-slate-400 uppercase tracking-wider pb-2 border-b border-slate-800">
                Websites, Blogs & Channels
              </div>

              <div className="space-y-3 text-sm">
                <div>
                  <div className="text-xs text-slate-500 font-medium mb-1">Publications & Research</div>
                  <div className="flex flex-col gap-2 text-xs font-mono">
                    <a
                      href="https://ieeexplore.ieee.org/document/10688954"
                      target="_blank"
                      rel="noreferrer"
                      className="text-cyan-300 hover:text-cyan-200 hover:underline flex items-center gap-1.5 p-2 rounded bg-cyan-950/40 border border-cyan-800/70"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="font-semibold text-white">IEEE Xplore Research (Doc 10688954)</span>
                      <ExternalLink className="w-3 h-3 text-cyan-400 ml-auto" />
                    </a>

                    <div className="flex flex-wrap gap-x-4 gap-y-1 pt-1">
                      <a
                        href="https://ezbugfix.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1"
                      >
                        <Globe className="w-3.5 h-3.5" />
                        <span>ezbugfix.com</span>
                      </a>
                      <span className="text-slate-700">·</span>
                      <a
                        href="https://goldchords.blogspot.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1"
                      >
                        <Globe className="w-3.5 h-3.5" />
                        <span>goldchords.blogspot.com</span>
                      </a>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/60">
                  <div className="text-xs text-slate-500 font-medium mb-1">YouTube Media Channels</div>
                  <div className="flex items-center gap-4 text-xs font-sans text-slate-300">
                    <div className="flex items-center gap-1.5 text-rose-400 font-medium">
                      <Youtube className="w-3.5 h-3.5" />
                      <span>Idea Infinity</span>
                    </div>
                    <span className="text-slate-700">·</span>
                    <div className="flex items-center gap-1.5 text-rose-400 font-medium">
                      <Youtube className="w-3.5 h-3.5" />
                      <span>Woow Look</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
